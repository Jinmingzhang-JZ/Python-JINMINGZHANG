from SaveData import save_data_to_csv
from ReadData import read_data_and_stats
from groupData import group_and_plot

def main():
    menu = """\n***** Grouped Data Analyzer *****

1. Enter Data and Save to CSV
2. Show Statistics
3. Draw Histogram
4. Exit

Enter your choice (1-4): """

    while True:
        choice = input(menu).strip()
        if choice == '1':
            save_data_to_csv()
        elif choice == '2':
            read_data_and_stats()
        elif choice == '3':
            group_and_plot()
        elif choice == '4':
            print("Goodbye!")
            break
        else:
            print("Invalid input. Please choose 1–4.")

if __name__ == "__main__":
    main()
