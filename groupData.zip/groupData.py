import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

def group_and_plot():
    try:
        df = pd.read_csv("sampleData-1.csv")
        data = df['Weight'].tolist()
        class_width = 5
        grouped_df, frequency, midpoints = group_data(data, class_width)
        draw_histogram(grouped_df, class_width)
    except Exception as e:
        print(f"Error: {e}")

def group_data(data, class_width):
    min_val, max_val = min(data), max(data)
    bins = np.arange(min_val, max_val + class_width, class_width)
    frequency, bin_edges = np.histogram(data, bins=bins)
    midpoints = [(bin_edges[i] + bin_edges[i+1]) / 2 for i in range(len(bin_edges)-1)]
    grouped_df = pd.DataFrame({
        'Classes': [f'{bin_edges[i]} - {bin_edges[i+1]}' for i in range(len(bin_edges)-1)],
        'Frequency': frequency,
        'Midpoint': midpoints
    })
    return grouped_df, frequency, midpoints

def draw_histogram(grouped_df, class_width):
    plt.bar(grouped_df['Midpoint'], grouped_df['Frequency'], width=class_width, color='skyblue', edgecolor='black')
    plt.xlabel("Midpoint")
    plt.ylabel("Frequency")
    plt.title("Histogram of Weight Data")
    max_freq = grouped_df['Frequency'].max()
    avg = grouped_df['Midpoint'].mean()
    plt.axhline(y=max_freq, color='r', linestyle='--', label=f'Max Frequency = {max_freq}')
    plt.axvline(x=avg, color='g', linestyle='--', label=f'Average = {avg:.2f}')
    plt.legend()
    plt.tight_layout()
    plt.show()
